# AL Ameen Pharmacy - IIS Deployment Instructions

**Date:** $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
**Environment:** Production - Windows Server with IIS
**Application:** AL Ameen Pharmacy Management System
**Framework:** .NET 8.0 ASP.NET Core
**Architecture:** x64

---

## ?? DEPLOYMENT PACKAGE CONTENTS

This folder contains the complete published application ready for deployment to IIS.

### Folder Structure:
```
ALAmeenPharmacy/
??? Shop.dll                    (Main Application Assembly)
??? Shop.exe                    (Windows Executable Host)
??? Shop.deps.json              (Dependencies Manifest)
??? Shop.runtimeconfig.json     (Runtime Configuration)
??? web.config                  (IIS Configuration - ALREADY CONFIGURED)
??? appsettings.json            (Default Settings)
??? appsettings.Production.json (Production Settings - EDIT THIS)
??? wwwroot/                    (Static Files - CSS, JS, Images)
??? Views/                      (Razor Views)
??? Pages/                      (Razor Pages)
??? runtimes/                   (Runtime-specific binaries)
??? [Other dependency DLLs]     (Framework & NuGet packages)
```

---

## ? PRE-DEPLOYMENT REQUIREMENTS (On Target Server)

### 1. **Install .NET 8.0 Hosting Bundle**
   - Download from: https://dotnet.microsoft.com/download/dotnet/8.0
   - Select: **Hosting Bundle** for Windows (x64)
   - Run installer: `dotnet-hosting-8.0.x-win.exe`
   - After installation, **restart IIS**: `iisreset /restart`

### 2. **Verify .NET Installation**
   ```powershell
   dotnet --info
   # Should show .NET 8.0.x installed
   ```

### 3. **SQL Server Requirements**
   - SQL Server 2016 or higher (or SQL Server Express)
   - Existing database: `ShopDb`
   - Connection string configured in `appsettings.Production.json`

### 4. **IIS Features Required**
   - IIS Web Server (with ASP.NET Core Module 2.0)
   - Static Content
   - HTTP Compression
   - URL Rewrite (optional, for HTTPS redirect)

---

## ?? DEPLOYMENT STEPS (On Target Server)

### Step 1: Copy Application Files

1. Copy this entire folder to the target IIS directory
   ```powershell
   Copy-Item -Path "D:\ALAmeenPharmacy" -Destination "C:\inetpub\wwwroot\ALAmeenPharmacy" -Recurse -Force
   ```

2. Or manually copy using File Explorer to:
   ```
   C:\inetpub\wwwroot\ALAmeenPharmacy\
   ```

### Step 2: Update Configuration

1. Open `C:\inetpub\wwwroot\ALAmeenPharmacy\appsettings.Production.json`

2. **Update the connection string** for your production database:
   ```json
   {
     "ConnectionStrings": {
       "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=ShopDb;Integrated Security=true;TrustServerCertificate=True;Encrypt=True"
     }
   }
   ```

   **Examples:**
   - **Local SQL Server Express:**
     ```
     Server=DGX8CK3\SQLEXPRESS;Database=ShopDb;Integrated Security=true;TrustServerCertificate=True
     ```
   - **Named Instance:**
     ```
     Server=SERVERNAME\INSTANCENAME;Database=ShopDb;Integrated Security=true
     ```
   - **Specific IP:**
     ```
     Server=192.168.1.100;Database=ShopDb;User Id=sa;Password=YourPassword;Encrypt=True;TrustServerCertificate=True
     ```

3. Update **AllowedHosts** for your domain:
   ```json
   "AllowedHosts": "yourdomain.com;www.yourdomain.com;localhost"
   ```

### Step 3: Create IIS Application Pool

1. **Open IIS Manager**
   - Press `Windows Key + R`, type `inetmgr`, press Enter

2. **Create New Application Pool:**
   - Right-click "Application Pools" ? "Add Application Pool"
   - **Name:** `ALAmeenPharmacy`
   - **.NET CLR Version:** `No Managed Code` (important!)
   - **Managed Pipeline Mode:** `Integrated`
   - **Click OK**

3. **Configure Application Pool:**
   - Right-click the new pool ? "Advanced Settings"
   - **Process Model:**
     - Identity: `ApplicationPoolIdentity`
     - Load User Profile: `True`
   - **Recycling:**
     - Regular Time Interval (minutes): `1440` (daily)
   - **Click OK**

### Step 4: Create IIS Website/Application

**Option A: New Website**
1. Right-click "Sites" ? "Add Website"
2. Fill in:
   - **Site Name:** `AL Ameen Pharmacy`
   - **Application Pool:** `ALAmeenPharmacy`
   - **Physical Path:** `C:\inetpub\wwwroot\ALAmeenPharmacy`
   - **IP Address:** All Unassigned
   - **Port:** `80` (HTTP) or `443` (HTTPS)
   - **Host Name:** (optional) `yourdomain.com`
3. **Click OK**

**Option B: Virtual Application (under existing website)**
1. Right-click existing website ? "Add Application"
2. Fill in:
   - **Alias:** `pharmacy` (or your choice)
   - **Application Pool:** `ALAmeenPharmacy`
   - **Physical Path:** `C:\inetpub\wwwroot\ALAmeenPharmacy`
3. **Click OK**

### Step 5: Set File Permissions

```powershell
# Run as Administrator
# Grant IIS App Pool identity full permissions
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy" /grant "IIS AppPool\ALAmeenPharmacy:(OI)(CI)F" /T /C

# Grant IUSR read permissions
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy" /grant "IUSR:(OI)(CI)R" /T /C

# Create logs directory if needed
mkdir "C:\inetpub\wwwroot\ALAmeenPharmacy\logs" -Force
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy\logs" /grant "IIS AppPool\ALAmeenPharmacy:(OI)(CI)F" /T /C
```

### Step 6: Start IIS Application

1. In IIS Manager, click on your website/application
2. In the right pane, click **"Start"** under **Manage Website**
3. Or run:
   ```powershell
   iisreset /start
   ```

### Step 7: Test Application

1. Open browser and navigate to: `http://localhost/` (or your configured URL)
2. Expected: AL Ameen Pharmacy login page
3. Check IIS logs if issues: `C:\inetpub\wwwroot\ALAmeenPharmacy\logs\`

---

## ?? CONFIGURATION REFERENCE

### appsettings.Production.json (Key Settings)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER;Database=ShopDb;Integrated Security=true;TrustServerCertificate=True"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Warning",
      "Microsoft.AspNetCore": "Warning",
      "Microsoft.EntityFrameworkCore": "Error"
    }
  },
  "AllowedHosts": "yourdomain.com;www.yourdomain.com",
  "DataProtection": {
    "ApplicationName": "ALAmeenPharmacy"
  }
}
```

### web.config (Already Pre-configured)

- ASP.NET Core Module v2 handler configured
- HTTP compression enabled
- Security headers configured
- Static file caching enabled
- File extensions blocked (.config, .dll, .exe)

---

## ?? HTTPS/SSL CONFIGURATION (Optional)

### After Installing SSL Certificate:

1. **Import Certificate to IIS:**
   ```powershell
   Import-PfxCertificate -FilePath "C:\certificate.pfx" `
     -CertStoreLocation Cert:\LocalMachine\My `
     -Password (ConvertTo-SecureString "password" -AsPlainText -Force)
   ```

2. **In IIS Manager:**
   - Right-click website ? "Edit Bindings"
   - Add new binding:
     - Type: `https`
     - Port: `443`
     - SSL Certificate: Select your certificate
   - Click OK

3. **Enable HTTPS Redirect in web.config:**
   - Edit `C:\inetpub\wwwroot\ALAmeenPharmacy\web.config`
   - Find the commented rule "Force HTTPS"
   - Change `enabled="false"` to `enabled="true"`
   - Save file

---

## ?? MONITORING & LOGS

### Log Locations:

| Log Type | Location |
|----------|----------|
| Application Logs | `C:\inetpub\wwwroot\ALAmeenPharmacy\logs\` |
| IIS Access Logs | `C:\inetpub\logs\LogFiles\W3SVC1\` |
| Windows Event Logs | Event Viewer ? Windows Logs ? Application |
| ASP.NET Core Output | `C:\inetpub\wwwroot\ALAmeenPharmacy\logs\stdout` |

### View Logs:
```powershell
# Follow real-time application logs
Get-Content -Path "C:\inetpub\wwwroot\ALAmeenPharmacy\logs\stdout*" -Wait

# Check IIS logs
Get-Content -Path "C:\inetpub\logs\LogFiles\W3SVC1\*.log" | tail -20
```

---

## ?? TROUBLESHOOTING

### Issue: "500 Internal Server Error"

**Solutions:**
1. Check database connection string in `appsettings.Production.json`
2. Verify SQL Server service is running
3. Check IIS logs: `C:\inetpub\logs\LogFiles\W3SVC1\`
4. Check ASP.NET Core logs: `C:\inetpub\wwwroot\ALAmeenPharmacy\logs\stdout*`
5. Verify database exists and is accessible

### Issue: "The site cannot be reached" / "Connection refused"

**Solutions:**
1. Verify IIS website is started (should be green in IIS Manager)
2. Check firewall allows port 80/443
3. Verify Application Pool identity is configured correctly
4. Restart IIS: `iisreset /restart`
5. Check Event Viewer for errors

### Issue: "File not found" / Static files not loading

**Solutions:**
1. Verify static files exist in `wwwroot` folder
2. Check IIS Static Content feature is enabled
3. Verify file permissions (see Step 5)
4. Clear browser cache (Ctrl+Shift+Delete)

### Issue: "Access Denied" errors

**Solutions:**
1. Re-run permission commands from Step 5
2. Ensure Application Pool identity is correct
3. Check file/folder NTFS permissions
4. Run IIS Manager as Administrator

---

## ?? POST-DEPLOYMENT CHECKLIST

- [ ] Application running and accessible
- [ ] Login/authentication working
- [ ] Database connection verified
- [ ] All pages loading correctly
- [ ] Static files (CSS, JS) loading
- [ ] Logs are being created
- [ ] Performance acceptable (test under load)
- [ ] Backups configured
- [ ] Monitoring/alerts configured
- [ ] SSL certificate installed (if HTTPS)
- [ ] Tested from multiple browsers
- [ ] Tested from remote machines

---

## ?? UPDATES & MAINTENANCE

### To Update Application:

1. Stop the IIS website
2. Backup current files: `Robocopy C:\inetpub\wwwroot\ALAmeenPharmacy C:\Backups\ALAmeenPharmacy.backup /E /V`
3. Copy new application files over existing ones
4. Start the IIS website

### Backup Strategy:

```powershell
# Daily backup script (add to Task Scheduler)
$source = "C:\inetpub\wwwroot\ALAmeenPharmacy"
$backupDir = "C:\Backups"
$date = Get-Date -Format "yyyyMMdd_HHmmss"
$destination = "$backupDir\ALAmeenPharmacy_$date"

Robocopy $source $destination /E /V

# Cleanup old backups (keep only 30 days)
Get-ChildItem $backupDir -Directory | Where-Object { $_.CreationTime -lt (Get-Date).AddDays(-30) } | Remove-Item -Recurse -Force
```

---

## ?? SUPPORT

For issues or questions:
1. Check logs in the locations mentioned above
2. Review the troubleshooting section
3. Verify all configuration steps completed
4. Contact your system administrator

---

## ?? NOTES

- **Do NOT modify files** in the application directory after deployment (except `appsettings.Production.json`)
- Keep **regular backups** of both application files and database
- Monitor **disk space** for logs
- Restart IIS after any configuration changes
- Test thoroughly before announcing to users

---

**Deployment Package Version:** 1.0
**Last Updated:** 2024
**Framework:** .NET 8.0 ASP.NET Core
