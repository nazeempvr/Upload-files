﻿// GLOBAL POS STATE
let invoiceItems = [];
let itemCounter = 0;

// ENHANCED AUTOCOMPLETE STATE
let searchTimeout = null;
let currentSelectedIndex = -1;
let currentResults = [];
const SEARCH_DEBOUNCE_MS = 280;
const MIN_SEARCH_CHARS = 2;
const MAX_RESULTS = 15;

document.addEventListener('DOMContentLoaded', function () {
    initializePOS();
    initializeAutocomplete();
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);
});

function initializePOS() {
    document.getElementById('clearStockSearch').addEventListener('click', function () {
        document.getElementById('stockSearchInput').value = '';
        hideDropdown();
        document.getElementById('stockSearchInput').focus();
    });
    document.getElementById('clearInvoiceBtn').addEventListener('click', clearInvoice);
    document.getElementById('saveInvoiceBtn').addEventListener('click', saveInvoice);
    document.getElementById('printReceiptBtn').addEventListener('click', printReceipt);
    document.getElementById('emailReceiptBtn').addEventListener('click', emailReceipt);
    document.getElementById('newInvoiceBtn').addEventListener('click', newInvoice);
}

function updateCurrentTime() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString();
}

function initializeAutocomplete() {
    buildDropdownContainer();

    const input = document.getElementById('stockSearchInput');

    input.addEventListener('input', function () {
        const term = this.value.trim();
        clearTimeout(searchTimeout);

        if (term.length < MIN_SEARCH_CHARS) {
            hideDropdown();
            setSpinner(false);
            return;
        }

        setSpinner(true);
        searchTimeout = setTimeout(() => fetchMedicines(term), SEARCH_DEBOUNCE_MS);
    });

    input.addEventListener('keydown', handleKeyboardNavigation);

    document.addEventListener('click', function (e) {
        if (!e.target.closest('.stock-search-container') && !e.target.closest('#posDropdown')) {
            hideDropdown();
        }
    });

    window.addEventListener('resize', repositionDropdown);
}

function buildDropdownContainer() {
    document.getElementById('posDropdown')?.remove();
    const el = document.createElement('div');
    el.id = 'posDropdown';
    el.className = 'pos-dropdown';
    el.setAttribute('role', 'listbox');
    el.setAttribute('aria-label', 'Medicine search results');
    document.body.appendChild(el);
}

function fetchMedicines(term) {
    fetch(`/Billing/api/stock/search?term=${encodeURIComponent(term)}&limit=${MAX_RESULTS}`)
        .then(r => r.json())
        .then(data => {
            setSpinner(false);
            if (data.success) {
                currentResults = data.medicines || [];
                renderDropdown(currentResults, data.searchTerm || term);
            } else {
                renderError(data.message || 'Search failed.');
            }
        })
        .catch(() => {
            setSpinner(false);
            renderError('Network error - please try again.');
        });
}

function renderDropdown(medicines, rawTerm) {
    const drop = document.getElementById('posDropdown');
    currentSelectedIndex = -1;

    if (!medicines.length) {
        drop.innerHTML = `
            <div class="pos-drop-empty">
                <i class="bi bi-search me-2"></i>No medicines found for "<strong>${escHtml(rawTerm)}</strong>"
            </div>`;
        positionAndShowDropdown();
        return;
    }

    drop.innerHTML = medicines.map((m, idx) => buildCard(m, idx, rawTerm)).join('');

    drop.querySelectorAll('.pos-drop-item').forEach((el, idx) => {
        el.addEventListener('click', () => chooseMedicine(idx));
        el.addEventListener('mouseenter', () => highlightItem(idx));
    });

    positionAndShowDropdown();
}

function buildCard(m, idx, rawTerm) {
    const term = escHtml(rawTerm);

    const stockBadge = m.isLowStock
        ? `<span class="badge bg-danger ms-1 pos-badge-xs">Low Stock</span>`
        : (m.quantityInStock <= 10
            ? `<span class="badge bg-warning text-dark ms-1 pos-badge-xs">Limited</span>`
            : '');

    const expiryBadge = m.isNearExpiry
        ? `<span class="badge bg-warning text-dark ms-1 pos-badge-xs"><i class="bi bi-clock-history me-1"></i>Near Expiry</span>`
        : '';

    const rxBadge = m.prescriptionRequired
        ? `<span class="badge bg-secondary ms-1 pos-badge-xs">Rx</span>`
        : '';

    const schBadge = m.scheduleClass
        ? `<span class="badge bg-info text-dark ms-1 pos-badge-xs">Sch-${escHtml(m.scheduleClass)}</span>`
        : '';

    const qtyClass = m.quantityInStock > 10 ? 'text-success'
        : m.quantityInStock > 0 ? 'text-warning'
        : 'text-danger';

    return `
    <div class="pos-drop-item" role="option" data-index="${idx}" tabindex="-1">
        <div class="pos-card-top">
            <div class="pos-card-left">
                <span class="pos-brand">${highlight(m.brandName, term)}</span>
                ${rxBadge}${schBadge}${expiryBadge}${stockBadge}
                <div class="pos-generic">${highlight(m.genericName, term)}</div>
                <div class="pos-composition">${highlight(m.composition, term)}</div>
            </div>
            <div class="pos-card-right">
                <div class="pos-price">₹${m.sellingPrice.toFixed(2)}</div>
                <div class="pos-gst">GST ${m.gstPercentage}%</div>
            </div>
        </div>
        <div class="pos-card-bottom">
            <span class="pos-meta"><i class="bi bi-capsule me-1"></i>${escHtml(m.form)}${m.packSize ? ' · ' + escHtml(m.packSize) : ''}</span>
            <span class="pos-meta"><i class="bi bi-tag me-1"></i>${highlight(m.category, term)}</span>
            <span class="pos-meta"><i class="bi bi-upc me-1"></i>${highlight(m.batchNumber, term)}</span>
            <span class="pos-meta"><i class="bi bi-calendar-x me-1"></i>Exp: ${escHtml(m.expiryDate)}</span>
            <span class="pos-meta ${qtyClass}"><i class="bi bi-boxes me-1"></i>${m.quantityInStock} units</span>
            <span class="pos-meta text-muted"><i class="bi bi-building me-1"></i>${highlight(m.supplierName, term)}</span>
        </div>
    </div>`;
}

function highlight(text, term) {
    if (!text || !term) return escHtml(text || '');
    const safe = escHtml(text);
    const safeTerm = escHtml(term).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return safe.replace(new RegExp(`(${safeTerm})`, 'gi'), '<mark class="pos-highlight">$1</mark>');
}

function escHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function renderError(msg) {
    const drop = document.getElementById('posDropdown');
    drop.innerHTML = `<div class="pos-drop-error"><i class="bi bi-exclamation-triangle me-2"></i>${escHtml(msg)}</div>`;
    positionAndShowDropdown();
}

function positionAndShowDropdown() {
    const drop = document.getElementById('posDropdown');
    const input = document.getElementById('stockSearchInput');
    const rect = input.getBoundingClientRect();
    const vpH = window.innerHeight;

    const spaceBelow = vpH - rect.bottom - 8;
    const spaceAbove = rect.top - 8;
    const dropMaxH = 420;

    drop.style.left = rect.left + window.scrollX + 'px';
    drop.style.width = Math.max(rect.width, 560) + 'px';

    if (spaceBelow >= Math.min(dropMaxH, 200) || spaceBelow >= spaceAbove) {
        drop.style.top = (rect.bottom + window.scrollY + 4) + 'px';
        drop.style.bottom = 'auto';
        drop.style.maxHeight = Math.min(dropMaxH, spaceBelow) + 'px';
    } else {
        drop.style.top = 'auto';
        drop.style.bottom = (vpH - rect.top + window.scrollY + 4) + 'px';
        drop.style.maxHeight = Math.min(dropMaxH, spaceAbove) + 'px';
    }

    drop.style.display = 'block';
}

function repositionDropdown() {
    if (document.getElementById('posDropdown')?.style.display === 'block') {
        positionAndShowDropdown();
    }
}

function hideDropdown() {
    const drop = document.getElementById('posDropdown');
    if (drop) drop.style.display = 'none';
    currentSelectedIndex = -1;
}

function handleKeyboardNavigation(e) {
    const drop = document.getElementById('posDropdown');
    const items = drop?.querySelectorAll('.pos-drop-item') || [];
    if (!items.length) return;

    switch (e.key) {
        case 'ArrowDown':
            e.preventDefault();
            currentSelectedIndex = Math.min(currentSelectedIndex + 1, items.length - 1);
            highlightItem(currentSelectedIndex);
            break;
        case 'ArrowUp':
            e.preventDefault();
            currentSelectedIndex = Math.max(currentSelectedIndex - 1, -1);
            currentSelectedIndex >= 0 ? highlightItem(currentSelectedIndex) : clearHighlight();
            break;
        case 'Enter':
            e.preventDefault();
            if (currentSelectedIndex >= 0) chooseMedicine(currentSelectedIndex);
            break;
        case 'Escape':
            hideDropdown();
            break;
        case 'Tab':
            hideDropdown();
            break;
    }
}

function highlightItem(index) {
    const drop = document.getElementById('posDropdown');
    const items = drop?.querySelectorAll('.pos-drop-item') || [];
    items.forEach(el => el.classList.remove('pos-selected'));
    if (items[index]) {
        items[index].classList.add('pos-selected');
        currentSelectedIndex = index;
        items[index].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
}

function clearHighlight() {
    document.querySelectorAll('.pos-drop-item').forEach(el => el.classList.remove('pos-selected'));
}

function chooseMedicine(index) {
    if (!currentResults[index]) return;
    addMedicineToInvoice(currentResults[index]);
    document.getElementById('stockSearchInput').value = '';
    hideDropdown();
    setTimeout(() => document.getElementById('stockSearchInput').focus(), 80);
}

function setSpinner(show) {
    const sp = document.getElementById('searchSpinner');
    sp.classList.toggle('d-none', !show);
}

function addMedicineToInvoice(medicine) {
    const existingItem = invoiceItems.find(item => item.medicineId === medicine.id);

    if (existingItem) {
        existingItem.quantity += 1;
        updateInvoiceItemDisplay(existingItem);
        showNotification('Increased quantity of ' + medicine.brandName, 'info');
    } else {
        const invoiceItem = {
            id: ++itemCounter,
            medicineId: medicine.id,
            brandName: medicine.brandName,
            genericName: medicine.genericName,
            category: medicine.category || 'General',
            composition: medicine.composition || medicine.genericName,
            form: medicine.form || 'Tablet',
            packSize: medicine.packSize || '1 Unit',
            batchNumber: medicine.batchNumber || 'N/A',
            unitPrice: medicine.sellingPrice,
            purchasePrice: medicine.purchasePrice || 0,
            gstPercentage: medicine.gstPercentage || 18,
            discountPercentage: medicine.discountPercentage || 0,
            quantity: 1,
            availableStock: medicine.quantityInStock,
            expiryDate: medicine.expiryDate || 'N/A',
            isNearExpiry: medicine.isNearExpiry || false,
            prescriptionRequired: medicine.prescriptionRequired || false,
            supplierName: medicine.supplierName || 'Unknown'
        };
        invoiceItems.push(invoiceItem);
        addInvoiceItemToAccordion(invoiceItem);
        showNotification('Added ' + medicine.brandName + ' to invoice', 'success');
    }

    updateInvoiceSummary();
    updateInvoiceVisibility();
}

function addInvoiceItemToAccordion(item) {
    const accordion = document.getElementById('invoiceAccordion');
    const accordionItem = document.createElement('div');
    accordionItem.className = 'accordion-item';
    accordionItem.setAttribute('data-item-id', item.id);

    const lineTotal = calculateLineTotal(item);

    const header = document.createElement('h2');
    header.className = 'accordion-header';
    header.id = 'heading-' + item.id;

    const button = document.createElement('button');
    button.className = 'accordion-button collapsed';
    button.type = 'button';
    button.setAttribute('data-bs-toggle', 'collapse');
    button.setAttribute('data-bs-target', '#collapse-' + item.id);
    button.setAttribute('aria-expanded', 'false');

    const buttonContent = document.createElement('div');
    buttonContent.className = 'w-100 d-flex justify-content-between align-items-center me-3';

    const leftDiv = document.createElement('div');
    leftDiv.innerHTML =
        '<strong class="text-primary">' + item.brandName + '</strong>' +
        '<span class="text-muted ms-2">' + item.genericName + '</span>' +
        (item.isNearExpiry ? '<span class="badge bg-warning text-dark ms-2">Near Expiry</span>' : '') +
        (item.prescriptionRequired ? '<span class="badge bg-warning text-dark ms-2">Rx</span>' : '') +
        '<span class="purchase-price-info ms-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Purchase Price: ' + 
        (item.purchasePrice > 0 ? '₹' + item.purchasePrice.toFixed(2) : 'Not Available') + 
        '"><i class="bi bi-info-circle text-muted" style="cursor: help; font-size: 0.9rem;"></i></span>';

    const rightDiv = document.createElement('div');
    rightDiv.className = 'text-end';
    rightDiv.innerHTML =
        '<div class="fw-bold">Qty: <span class="quantity-display">' + item.quantity + '</span> × ₹' + item.unitPrice.toFixed(2) + ' = ' +
        '<span class="text-success line-total">₹' + lineTotal.toFixed(2) + '</span></div>';

    buttonContent.appendChild(leftDiv);
    buttonContent.appendChild(rightDiv);
    button.appendChild(buttonContent);
    header.appendChild(button);

    const collapseDiv = document.createElement('div');
    collapseDiv.id = 'collapse-' + item.id;
    collapseDiv.className = 'accordion-collapse collapse';
    collapseDiv.setAttribute('data-bs-parent', '#invoiceAccordion');

    const accordionBody = document.createElement('div');
    accordionBody.className = 'accordion-body';
    accordionBody.innerHTML = createAccordionBodyContent(item, lineTotal);

    collapseDiv.appendChild(accordionBody);
    accordionItem.appendChild(header);
    accordionItem.appendChild(collapseDiv);
    accordion.appendChild(accordionItem);

    // Initialize Bootstrap tooltip for this item
    const tooltipElement = accordionItem.querySelector('.purchase-price-info');
    if (tooltipElement) {
        new bootstrap.Tooltip(tooltipElement);
    }
}

function createAccordionBodyContent(item, lineTotal) {
    return '<div class="row">' +
        '<div class="col-md-8">' +
            '<table class="table table-sm">' +
                '<tr><td><strong>Category:</strong></td><td>' + item.category + '</td></tr>' +
                '<tr><td><strong>Composition:</strong></td><td>' + item.composition + '</td></tr>' +
                '<tr><td><strong>Form & Pack:</strong></td><td>' + item.form + (item.packSize ? ' - ' + item.packSize : '') + '</td></tr>' +
                '<tr><td><strong>Batch Number:</strong></td><td>' + item.batchNumber + '</td></tr>' +
                '<tr><td><strong>Expiry Date:</strong></td><td>' + item.expiryDate + '</td></tr>' +
                '<tr><td><strong>Supplier:</strong></td><td>' + item.supplierName + '</td></tr>' +
                '<tr><td><strong>Available Stock:</strong></td><td class="text-' + (item.availableStock > 10 ? 'success' : 'warning') + '">' + item.availableStock + ' units</td></tr>' +
            '</table>' +
        '</div>' +
        '<div class="col-md-4">' +
            createItemControlsContent(item, lineTotal) +
        '</div>' +
    '</div>';
}

function createItemControlsContent(item, lineTotal) {
    const gstAmount = lineTotal * item.gstPercentage / 100;
    const totalWithGST = lineTotal + gstAmount;
    const discountAmount = item.unitPrice * item.quantity * item.discountPercentage / 100;

    return '<div class="card">' +
        '<div class="card-body">' +
            '<h6 class="card-title">Item Controls</h6>' +
            '<div class="mb-3">' +
                '<label class="form-label">Quantity</label>' +
                '<div class="input-group">' +
                    '<button class="btn btn-outline-secondary" type="button" onclick="changeQuantity(' + item.id + ', -1)">-</button>' +
                    '<input type="number" class="form-control text-center quantity-input" value="' + item.quantity + '" min="1" max="' + item.availableStock + '" onchange="updateQuantity(' + item.id + ', this.value)">' +
                    '<button class="btn btn-outline-secondary" type="button" onclick="changeQuantity(' + item.id + ', 1)">+</button>' +
                '</div>' +
            '</div>' +
            '<div class="mb-3">' +
                '<label class="form-label">Discount %</label>' +
                '<input type="number" class="form-control discount-input" value="' + item.discountPercentage + '" min="0" max="100" step="0.1" onchange="updateDiscount(' + item.id + ', this.value)">' +
            '</div>' +
            '<hr>' +
            '<div class="pricing-details">' +
                '<div class="d-flex justify-content-between"><span>Unit Price:</span><span>₹' + item.unitPrice.toFixed(2) + '</span></div>' +
                '<div class="d-flex justify-content-between"><span>Quantity:</span><span class="quantity-detail">' + item.quantity + '</span></div>' +
                '<div class="d-flex justify-content-between text-success"><span>Discount:</span><span class="discount-amount">-₹' + discountAmount.toFixed(2) + '</span></div>' +
                '<div class="d-flex justify-content-between"><span>GST (' + item.gstPercentage + '%):</span><span class="gst-amount">₹' + gstAmount.toFixed(2) + '</span></div>' +
                '<hr>' +
                '<div class="d-flex justify-content-between fw-bold"><span>Total:</span><span class="item-total">₹' + totalWithGST.toFixed(2) + '</span></div>' +
            '</div>' +
            '<hr>' +
            '<button type="button" class="btn btn-outline-danger btn-sm w-100" onclick="removeInvoiceItem(' + item.id + ')">' +
                '<i class="bi bi-trash me-1"></i>Remove Item' +
            '</button>' +
        '</div>' +
    '</div>';
}

function calculateLineTotal(item) {
    const subtotal = item.quantity * item.unitPrice;
    return subtotal - (subtotal * item.discountPercentage / 100);
}

function changeQuantity(itemId, change) {
    const item = invoiceItems.find(i => i.id === itemId);
    if (!item) return;
    const nq = Math.max(1, Math.min(item.availableStock, item.quantity + change));
    if (nq !== item.quantity) {
        item.quantity = nq;
        updateInvoiceItemDisplay(item);
        updateInvoiceSummary();
    }
}

function updateQuantity(itemId, newQuantity) {
    const item = invoiceItems.find(i => i.id === itemId);
    if (!item) return;
    item.quantity = Math.max(1, Math.min(item.availableStock, parseInt(newQuantity) || 1));
    updateInvoiceItemDisplay(item);
    updateInvoiceSummary();
}

function updateDiscount(itemId, newDiscount) {
    const item = invoiceItems.find(i => i.id === itemId);
    if (!item) return;
    item.discountPercentage = Math.max(0, Math.min(100, parseFloat(newDiscount) || 0));
    updateInvoiceItemDisplay(item);
    updateInvoiceSummary();
}

function updateInvoiceItemDisplay(item) {
    const el = document.querySelector('[data-item-id="' + item.id + '"]');
    if (!el) return;
    const lineTotal = calculateLineTotal(item);
    const totalWithGST = lineTotal + lineTotal * item.gstPercentage / 100;

    el.querySelector('.quantity-display').textContent = item.quantity;
    el.querySelector('.line-total').textContent = '₹' + lineTotal.toFixed(2);
    el.querySelector('.quantity-input').value = item.quantity;
    el.querySelector('.discount-input').value = item.discountPercentage;
    el.querySelector('.quantity-detail').textContent = item.quantity;
    el.querySelector('.discount-amount').textContent = '-₹' + (item.unitPrice * item.quantity * item.discountPercentage / 100).toFixed(2);
    el.querySelector('.gst-amount').textContent = '₹' + (lineTotal * item.gstPercentage / 100).toFixed(2);
    el.querySelector('.item-total').textContent = '₹' + totalWithGST.toFixed(2);
}

function removeInvoiceItem(itemId) {
    if (!confirm('Are you sure you want to remove this item from the invoice?')) return;
    invoiceItems = invoiceItems.filter(i => i.id !== itemId);
    document.querySelector('[data-item-id="' + itemId + '"]')?.remove();
    updateInvoiceSummary();
    updateInvoiceVisibility();
    showNotification('Item removed from invoice', 'info');
}

function updateInvoiceSummary() {
    let subtotal = 0, totalDiscount = 0, totalGST = 0, netTotal = 0;
    invoiceItems.forEach(item => {
        const s = item.quantity * item.unitPrice;
        const d = s * item.discountPercentage / 100;
        const l = s - d;
        const g = l * item.gstPercentage / 100;
        subtotal += s;
        totalDiscount += d;
        totalGST += g;
        netTotal += l + g;
    });

    document.getElementById('totalItems').textContent = invoiceItems.length;
    document.getElementById('subtotalAmount').textContent = '₹' + subtotal.toFixed(2);
    document.getElementById('totalDiscountAmount').textContent = '-₹' + totalDiscount.toFixed(2);
    document.getElementById('totalGSTAmount').textContent = '₹' + totalGST.toFixed(2);
    document.getElementById('netTotalAmount').textContent = '₹' + netTotal.toFixed(2);
}

function updateInvoiceVisibility() {
    const has = invoiceItems.length > 0;
    document.getElementById('emptyInvoiceState').style.display = has ? 'none' : 'block';
    document.getElementById('invoiceItemsContainer').style.display = has ? 'block' : 'none';
    document.getElementById('clearInvoiceBtn').style.display = has ? 'inline-block' : 'none';
    document.getElementById('invoiceActions').style.display = has ? 'block' : 'none';
    document.getElementById('noItemsMessage').style.display = has ? 'none' : 'block';
}

function clearInvoice() {
    if (!confirm('Are you sure you want to clear all items from this invoice?')) return;
    invoiceItems = [];
    itemCounter = 0;
    document.getElementById('invoiceAccordion').innerHTML = '';
    updateInvoiceSummary();
    updateInvoiceVisibility();
    document.getElementById('customerName').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('paymentMethod').value = 'Cash';
    showNotification('Invoice cleared', 'info');
}

function saveInvoice() {
    if (!invoiceItems.length) {
        showNotification('Please add items to the invoice before saving', 'warning');
        return;
    }

    const customerName = document.getElementById('customerName').value.trim();
    const customerPhone = document.getElementById('customerPhone').value.trim();
    const paymentMethod = document.getElementById('paymentMethod').value;

    if (!customerName) {
        showNotification('Please enter customer name', 'warning');
        document.getElementById('customerName').focus();
        return;
    }

    const stockValidationPromises = invoiceItems.map(item =>
        fetch('/Billing/ValidateStock?medicineId=' + item.medicineId + '&requestedQuantity=' + item.quantity)
            .then(r => r.json())
            .then(data => ({ item, validation: data }))
    );

    showLoadingOverlay(true);
    Promise.all(stockValidationPromises)
        .then(results => {
            const invalid = results.filter(r => !r.validation.isValid);
            if (invalid.length) {
                showLoadingOverlay(false);
                showNotification('Stock validation failed:\n' + invalid.map(r => r.item.brandName + ': ' + r.validation.message).join('\n'), 'error');
                return;
            }

            const nearExpiry = results.filter(r => r.validation.isNearExpiry);
            if (nearExpiry.length) {
                if (!confirm('The following items are near expiry: ' + nearExpiry.map(r => r.item.brandName).join(', ') + '. Do you want to continue?')) {
                    showLoadingOverlay(false);
                    return;
                }
            }

            proceedWithInvoiceSave(customerName, customerPhone, paymentMethod);
        })
        .catch(err => {
            showLoadingOverlay(false);
            console.error(err);
            showNotification('Error validating stock. Please try again.', 'error');
        });
}

function proceedWithInvoiceSave(customerName, customerPhone, paymentMethod) {
    let subtotal = 0, totalGST = 0, totalDiscount = 0, netTotal = 0;

    const invoiceItemRequests = invoiceItems.map(item => {
        const s = item.quantity * item.unitPrice;
        const d = s * item.discountPercentage / 100;
        const l = s - d;
        const g = l * item.gstPercentage / 100;
        subtotal += s;
        totalDiscount += d;
        totalGST += g;
        netTotal += l + g;

        return {
            medicineId: item.medicineId,
            brandName: item.brandName,
            genericName: item.genericName,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            discountPercentage: item.discountPercentage,
            gstPercentage: item.gstPercentage,
            lineTotal: l + g
        };
    });

    const invoiceRequest = {
        customerName,
        customerPhone,
        paymentMethod,
        items: invoiceItemRequests,
        subTotal: subtotal,
        totalGST,
        totalDiscount,
        netTotal
    };

    fetch('/Billing/SaveInvoice', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
        },
        body: JSON.stringify(invoiceRequest)
    })
        .then(r => r.json())
        .then(data => {
            showLoadingOverlay(false);
            if (data.success) {
                showNotification('Invoice ' + data.invoiceNumber + ' saved successfully! Total: ₹' + data.totalAmount.toFixed(2), 'success');
                window.currentInvoiceId = data.invoiceId;
                window.currentInvoiceNumber = data.invoiceNumber;
                showInvoiceSuccessOptions(data);
            } else {
                showNotification('Failed to save invoice: ' + (data.errors?.join('\n') || data.message), 'error');
            }
        })
        .catch(err => {
            showLoadingOverlay(false);
            console.error(err);
            showNotification('Error saving invoice. Please try again.', 'error');
        });
}

function showInvoiceSuccessOptions(invoiceData) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'invoiceSuccessModal';
    modal.innerHTML =
        '<div class="modal-dialog modal-lg"><div class="modal-content">' +
            '<div class="modal-header bg-success text-white"><h5 class="modal-title"><i class="bi bi-check-circle me-2"></i>Invoice Saved Successfully!</h5></div>' +
            '<div class="modal-body text-center">' +
                '<div class="mb-4"><h4 class="text-success">Invoice ' + invoiceData.invoiceNumber + '</h4>' +
                '<p class="text-muted">Date: ' + invoiceData.invoiceDate + '</p>' +
                '<h3 class="text-primary">Total: ₹' + invoiceData.totalAmount.toFixed(2) + '</h3></div>' +
                '<div class="d-grid gap-2">' +
                    '<button type="button" class="btn btn-primary btn-lg" onclick="printReceipt()"><i class="bi bi-printer me-2"></i>Print Receipt</button>' +
                    '<button type="button" class="btn btn-info" onclick="emailReceipt()"><i class="bi bi-envelope me-2"></i>Email Receipt</button>' +
                    '<hr>' +
                    '<button type="button" class="btn btn-warning" onclick="newInvoice(); closeSuccessModal()"><i class="bi bi-plus-circle me-2"></i>New Invoice</button>' +
                    '<button type="button" class="btn btn-outline-secondary" onclick="closeSuccessModal()">Close</button>' +
                '</div></div></div></div>';

    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    modal.addEventListener('hidden.bs.modal', () => modal.remove());
}

function closeSuccessModal() {
    const m = document.getElementById('invoiceSuccessModal');
    if (m) bootstrap.Modal.getInstance(m)?.hide();
}

function printReceipt() {
    if (!window.currentInvoiceId) {
        showNotification('No invoice available to print', 'warning');
        return;
    }

    showLoadingOverlay(true);
    fetch(`/Billing/GetInvoiceForPrint?invoiceId=${window.currentInvoiceId}`)
        .then(r => r.json())
        .then(data => {
            showLoadingOverlay(false);
            data.success ? generatePrintableReceipt(data.invoice) : showNotification('Failed to load invoice: ' + data.message, 'error');
        })
        .catch(() => {
            showLoadingOverlay(false);
            showNotification('Error loading invoice for printing.', 'error');
        });
}

function generatePrintableReceipt(invoice) {
    const pw = window.open('', '_blank', 'width=800,height=600');
    pw.document.write(`<!DOCTYPE html><html><head><title>Receipt - ${invoice.invoiceNumber}</title>
    <style>
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.4;
            margin: 0;
            padding: 10px;
            max-width: 80mm;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .pharmacy-name {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .invoice-info div, .totals div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2px;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .items-table th, .items-table td {
            text-align: left;
            padding: 2px;
            border-bottom: 1px solid #ccc;
        }
        .items-table th {
            border-bottom: 2px solid #000;
            font-weight: bold;
        }
        .item-name {
            font-weight: bold;
        }
        .totals {
            border-top: 2px solid #000;
            padding-top: 5px;
        }
        .net-total {
            font-weight: bold;
            font-size: 14px;
            border-top: 1px solid #000;
            padding-top: 2px;
        }
        .footer {
            text-align: center;
            border-top: 2px solid #000;
            padding-top: 10px;
            margin-top: 10px;
            font-size: 10px;
        }
        @media print {
            body {
                margin: 0;
                padding: 5px;
            }
        }
    </style>
    </head>
    <body>
    <div class="header">
        <div class="pharmacy-name">AL AMEEN PHARMACY</div>
        <div>Kerala, India</div>
        <div>GSTIN: 32XXXXX1234X1ZX</div>
        <div>Ph: +91-XXXXXXXXXX</div>
    </div>
    <div class="invoice-info">
        <div><span>Invoice:</span><span>${invoice.invoiceNumber}</span></div>
        <div><span>Date:</span><span>${invoice.invoiceDate}</span></div>
        ${invoice.customerName ? `<div><span>Customer:</span><span>${invoice.customerName}</span></div>` : ''}
        ${invoice.customerPhone ? `<div><span>Phone:</span><span>${invoice.customerPhone}</span></div>` : ''}
        <div><span>Payment:</span><span>${invoice.paymentMethod}</span></div>
    </div>
    <table class="items-table">
        <thead>
            <tr><th>Item</th><th>Qty</th><th>Rate</th><th>Total</th></tr>
        </thead>
        <tbody>
            ${invoice.items.map(i => `
                <tr>
                    <td>
                        <div class="item-name">${i.brandName}</div>
                        <div style="font-size:10px;color:#666">${i.genericName}</div>
                        <div style="font-size:9px;color:#999">Batch: ${i.batchNumber}</div>
                        ${i.discountPercentage > 0 ? `<div style="font-size:9px;color:#999">Disc: ${i.discountPercentage}%</div>` : ''}
                        ${i.gstPercentage > 0 ? `<div style="font-size:9px;color:#999">GST: ${i.gstPercentage}%</div>` : ''}
                    </td>
                    <td>${i.quantity}</td>
                    <td>₹${i.unitPrice.toFixed(2)}</td>
                    <td>₹${i.lineTotal.toFixed(2)}</td>
                </tr>`).join('')}
        </tbody>
    </table>
    <div class="totals">
        <div><span>Subtotal:</span><span>₹${invoice.subTotal.toFixed(2)}</span></div>
        ${invoice.totalDiscount > 0 ? `<div><span>Discount:</span><span>-₹${invoice.totalDiscount.toFixed(2)}</span></div>` : ''}
        <div><span>GST:</span><span>₹${invoice.totalGST.toFixed(2)}</span></div>
        <div class="net-total"><span>NET TOTAL:</span><span>₹${invoice.netTotal.toFixed(2)}</span></div>
    </div>
    <div class="footer">
        <div>*** THANK YOU FOR YOUR VISIT ***</div>
        <div>*** KEEP THE RECEIPT SAFE ***</div>
        <div>For queries: info@alameenpharmacy.com</div>
    </div>
    </body>
    </html>`);
    pw.document.close();
    setTimeout(() => { pw.print(); pw.close(); }, 500);
}

function emailReceipt() {
    if (!window.currentInvoiceId) {
        showNotification('No invoice available to email', 'warning');
        return;
    }

    const email = prompt('Enter customer email address:');
    if (!email || !email.includes('@')) {
        showNotification('Please enter a valid email address', 'warning');
        return;
    }

    showNotification('Email receipt functionality will be implemented soon. Receipt would be sent to: ' + email, 'info');
}

function newInvoice() {
    if (invoiceItems.length > 0 && !confirm('This will clear the current invoice. Are you sure?')) return;
    clearInvoice();
    document.getElementById('stockSearchInput').focus();
}

function showLoadingOverlay(show) {
    document.getElementById('loadingOverlay').style.display = show ? 'block' : 'none';
}

function showNotification(message, type) {
    const n = document.createElement('div');
    n.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    n.style.cssText = 'top:20px;right:20px;z-index:10000;min-width:300px;white-space:pre-line';
    n.innerHTML = message + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    document.body.appendChild(n);
    setTimeout(() => n.parentNode && n.remove(), 5000);
}
