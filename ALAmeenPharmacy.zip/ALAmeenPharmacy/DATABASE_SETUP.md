# Database Setup & Migration Guide

## Overview
This guide explains how to prepare and migrate the database for AL Ameen Pharmacy production deployment.

---

## Database Requirements

### SQL Server Version
- SQL Server 2016 SP2 or later
- SQL Server Express (local development)
- SQL Server on Azure SQL Database (cloud)

### Permissions Required
- dbcreator role (to create database)
- ALTER ANY LOGIN permission
- CREATE LOGIN permission

---

## Pre-Deployment Database Setup

### Option 1: Using Existing Database

If database already exists on the target server:

1. **Verify Database Exists:**
   ```sql
   SELECT name FROM sys.databases WHERE name = 'ShopDb'
   ```

2. **Create Application User (Recommended):**
   ```sql
   -- Create login
   CREATE LOGIN [ALAmeenPharmacyUser] WITH PASSWORD = 'YourSecurePassword123!';
   
   -- Create user
   USE ShopDb;
   CREATE USER [ALAmeenPharmacyUser] FOR LOGIN [ALAmeenPharmacyUser];
   
   -- Grant permissions
   ALTER ROLE db_datareader ADD MEMBER [ALAmeenPharmacyUser];
   ALTER ROLE db_datawriter ADD MEMBER [ALAmeenPharmacyUser];
   ALTER ROLE db_ddladmin ADD MEMBER [ALAmeenPharmacyUser];
   ```

3. **Connection String:**
   ```
   Server=YOUR_SERVER;Database=ShopDb;User Id=ALAmeenPharmacyUser;Password=YourSecurePassword123!;Encrypt=True;TrustServerCertificate=False
   ```

### Option 2: Create Fresh Database

If creating new database:

1. **Create Database:**
   ```sql
   CREATE DATABASE ShopDb
   ON
   (
     NAME = ShopDb_data,
     FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\ShopDb.mdf',
     SIZE = 100MB,
     MAXSIZE = 1GB,
     FILEGROWTH = 10MB
   )
   LOG ON
   (
     NAME = ShopDb_log,
     FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\ShopDb.ldf',
     SIZE = 50MB,
     MAXSIZE = 500MB,
     FILEGROWTH = 5MB
   );
   ```

2. **Create Application User:**
   ```sql
   USE master;
   CREATE LOGIN [ALAmeenPharmacyUser] WITH PASSWORD = 'YourSecurePassword123!';
   
   USE ShopDb;
   CREATE USER [ALAmeenPharmacyUser] FOR LOGIN [ALAmeenPharmacyUser];
   
   GRANT CONTROL ON DATABASE::ShopDb TO [ALAmeenPharmacyUser];
   ```

---

## Entity Framework Core Migrations

### What are Migrations?

Migrations are .NET classes that describe database schema changes. They:
- Create new tables and columns
- Establish relationships
- Set up indexes
- Initialize seed data

### Available Migrations

The application includes migrations for:
- Initial database schema
- Identity (User authentication)
- Medicine inventory
- Suppliers
- Invoicing system

### Applying Migrations

#### Option A: From Visual Studio (Development Machine)

```powershell
# Package Manager Console
Update-Database -Configuration Configuration -StartupProjectName Shop -ProjectName Shop -Verbose
```

#### Option B: Using .NET CLI (Recommended for Production)

On the target server with .NET installed:

```powershell
# Set environment to Production
$env:ASPNETCORE_ENVIRONMENT = "Production"

# Navigate to project
cd "C:\Users\232053\source\repos\Pharmacy\repo\Shop"

# Apply all pending migrations
dotnet ef database update --connection "Server=YOUR_SERVER;Database=ShopDb;User Id=ALAmeenPharmacyUser;Password=YourSecurePassword123!;Encrypt=True;TrustServerCertificate=False"
```

#### Option C: Using Publish Profile

```powershell
# Via connection string in appsettings
dotnet ef database update --project . --context ApplicationDbContext
```

---

## Verifying Database Setup

After migration, verify the database:

```sql
-- Check database exists
SELECT name FROM sys.databases WHERE name = 'ShopDb';

-- Check tables created
SELECT TABLE_NAME FROM ShopDb.INFORMATION_SCHEMA.TABLES 
WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME;

-- Check some key tables
SELECT COUNT(*) as MedicineCount FROM dbo.Medicines;
SELECT COUNT(*) as SupplierCount FROM dbo.Suppliers;
SELECT COUNT(*) as InvoiceCount FROM dbo.Invoices;

-- Check users
SELECT * FROM sys.sysusers WHERE issqluser = 1;

-- Check permissions
EXECUTE sp_helprolemember 'db_datareader';
EXECUTE sp_helprolemember 'db_datawriter';
```

---

## Expected Database Schema

### Core Tables

| Table | Purpose |
|-------|---------|
| AspNetUsers | User accounts for authentication |
| AspNetRoles | User roles (Admin, Manager, User) |
| AspNetUserRoles | User-to-role mapping |
| Medicines | Medicine inventory master |
| Suppliers | Medicine supplier information |
| Invoices | Sales invoices |
| InvoiceItems | Individual line items in invoices |
| Categories | Medicine categories (optional) |

### Important Indexes

The migrations create indexes on:
- MedicineId (Medicines table)
- SupplierId (Medicines table)
- InvoiceDate (Invoices table)
- UserId (Invoices table)

---

## Connection String Examples

### Local Development
```
Server=(localdb)\MSSQLLocalDB;Database=ShopDb;Trusted_Connection=True;MultipleActiveResultSets=True;TrustServerCertificate=True
```

### SQL Server Express (Named Instance)
```
Server=COMPUTER_NAME\SQLEXPRESS;Database=ShopDb;Integrated Security=true;TrustServerCertificate=True;Encrypt=True
```

### Specific SQL User
```
Server=COMPUTER_NAME;Database=ShopDb;User Id=ALAmeenPharmacyUser;Password=SecurePassword123!;Encrypt=True;TrustServerCertificate=True
```

### Azure SQL Database
```
Server=tcp:servername.database.windows.net,1433;Initial Catalog=ShopDb;Persist Security Info=False;User ID=sqladmin;Password=YourSecurePassword123!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;
```

---

## Troubleshooting Database Issues

### Issue: Cannot Connect to Database

**Symptoms:** "Cannot open database" or "Login failed"

**Solutions:**
1. Verify SQL Server service running: `Get-Service MSSQL$SQLEXPRESS | Select -ExpandProperty Status`
2. Verify server name: `SELECT @@SERVERNAME`
3. Test connection:
   ```powershell
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = "Server=YOUR_SERVER;Database=master;Integrated Security=true"
   $conn.Open()
   ```

### Issue: Authentication Failed

**Symptoms:** "Login failed for user..."

**Solutions:**
1. Verify credentials in connection string
2. Check if user exists:
   ```sql
   SELECT name FROM sys.sysusers WHERE name = 'ALAmeenPharmacyUser'
   ```
3. Reset password:
   ```sql
   ALTER LOGIN [ALAmeenPharmacyUser] WITH PASSWORD = 'NewPassword123!'
   ```

### Issue: Insufficient Permissions

**Symptoms:** "The server principal is not able to access the database"

**Solutions:**
1. Grant permissions:
   ```sql
   USE ShopDb
   ALTER ROLE db_owner ADD MEMBER [ALAmeenPharmacyUser]
   ```

### Issue: Migration Fails

**Symptoms:** "There are pending model changes" or migration errors

**Solutions:**
1. Ensure EntityFrameworkCore tools installed:
   ```powershell
   dotnet tool install --global dotnet-ef
   ```
2. Check connection string format
3. Ensure appropriate permissions

---

## Database Backup & Recovery

### Create Backup

```sql
-- Full database backup
BACKUP DATABASE ShopDb 
TO DISK = 'C:\Backups\ShopDb_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + '.bak'
WITH INIT, COMPRESSION;

-- Transaction log backup
BACKUP LOG ShopDb 
TO DISK = 'C:\Backups\ShopDb_Log_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + '.trn'
WITH INIT, COMPRESSION;
```

### Schedule Automated Backups

```sql
-- Create maintenance plan or SQL Agent job
-- Backup daily at 2:00 AM
USE msdb;
EXEC sp_add_job @job_name=N'ShopDb_Backup';
```

### Restore from Backup

```sql
-- Restore full database
RESTORE DATABASE ShopDb 
FROM DISK = 'C:\Backups\ShopDb_20240115_020000.bak'
WITH REPLACE;

-- Verify restore
DBCC CHECKDB (ShopDb);
```

---

## Performance Optimization

### Create Indexes

```sql
-- Index on frequently searched fields
CREATE INDEX IX_Medicines_BrandName ON dbo.Medicines(BrandName);
CREATE INDEX IX_Medicines_GenericName ON dbo.Medicines(GenericName);
CREATE INDEX IX_Invoices_InvoiceDate ON dbo.Invoices(InvoiceDate DESC);
CREATE INDEX IX_InvoiceItems_MedicineId ON dbo.InvoiceItems(MedicineId);
```

### Maintenance Tasks

```sql
-- Update statistics
EXEC sp_updatestats;

-- Rebuild indexes
ALTER INDEX ALL ON dbo.Medicines REBUILD;
ALTER INDEX ALL ON dbo.Invoices REBUILD;

-- Check database integrity
DBCC CHECKDB (ShopDb);
```

### Monitor Performance

```sql
-- Check query performance
SELECT TOP 10 
    qs.execution_count,
    qs.total_elapsed_time/1000000 as total_elapsed_sec,
    qs.total_elapsed_time/qs.execution_count/1000 as avg_elapsed_ms,
    SUBSTRING(st.text, 1, 50) as query_text
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
ORDER BY qs.total_elapsed_time DESC;
```

---

## Troubleshooting Checklist

- [ ] SQL Server service running
- [ ] Database created
- [ ] Application user created with correct permissions
- [ ] Connection string accurate
- [ ] .NET migrations applied successfully
- [ ] Tables exist and have data
- [ ] No blocked users or failed logins
- [ ] Backups configured and tested
- [ ] Performance acceptable

---

## Additional Resources

- [Entity Framework Core Documentation](https://docs.microsoft.com/en-us/ef/core/)
- [SQL Server Best Practices](https://docs.microsoft.com/en-us/sql/relational-databases/)
- [Connection Strings](https://www.connectionstrings.com/sql-server/)

---

**Last Updated:** 2024  
**Framework:** .NET 8.0 Entity Framework Core  
**Database:** SQL Server 2016+
