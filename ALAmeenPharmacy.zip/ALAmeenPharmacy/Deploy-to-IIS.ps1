# AL Ameen Pharmacy - Automated IIS Deployment Script
# This script automates the deployment process
# Run as Administrator on the target server

param(
    [Parameter(Mandatory=$false)]
    [string]$ApplicationPath = "C:\inetpub\wwwroot\ALAmeenPharmacy",
    
    [Parameter(Mandatory=$false)]
    [string]$ApplicationPoolName = "ALAmeenPharmacy",
    
    [Parameter(Mandatory=$false)]
    [string]$SiteName = "AL Ameen Pharmacy",
    
    [Parameter(Mandatory=$false)]
    [int]$Port = 80,
    
    [Parameter(Mandatory=$false)]
    [string]$Hostname = "localhost"
)

# Color output functions
function Write-Success {
    Write-Host "? $args" -ForegroundColor Green
}

function Write-Error-Custom {
    Write-Host "? $args" -ForegroundColor Red
}

function Write-Warning-Custom {
    Write-Host "? $args" -ForegroundColor Yellow
}

function Write-Info {
    Write-Host "? $args" -ForegroundColor Cyan
}

# Check if running as Administrator
function Test-Administrator {
    $currentPrincipal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

# Main deployment function
function Deploy-Application {
    Write-Host "
??????????????????????????????????????????????????????????????????
?  AL Ameen Pharmacy - IIS Deployment Script                    ?
?  .NET 8.0 ASP.NET Core Application                            ?
??????????????????????????????????????????????????????????????????
" -ForegroundColor Cyan

    # Check admin rights
    if (-not (Test-Administrator)) {
        Write-Error-Custom "This script must run as Administrator!"
        exit 1
    }
    Write-Success "Running as Administrator"

    # Step 1: Verify IIS is installed
    Write-Info "`nStep 1: Verifying IIS Installation..."
    try {
        $iisInstalled = Get-WindowsFeature -Name Web-Server | Select-Object -ExpandProperty Installed
        if ($iisInstalled) {
            Write-Success "IIS Web Server is installed"
        } else {
            Write-Error-Custom "IIS Web Server is not installed. Please install IIS first."
            exit 1
        }
    }
    catch {
        Write-Error-Custom "Error checking IIS installation: $_"
        exit 1
    }

    # Step 2: Import WebAdministration module
    Write-Info "`nStep 2: Loading IIS Management Module..."
    try {
        Import-Module WebAdministration -ErrorAction Stop
        Write-Success "WebAdministration module loaded"
    }
    catch {
        Write-Error-Custom "Failed to load WebAdministration module: $_"
        exit 1
    }

    # Step 3: Verify application pool doesn't exist
    Write-Info "`nStep 3: Checking Application Pool..."
    try {
        $poolPath = "IIS:\AppPools\$ApplicationPoolName"
        if (Test-Path $poolPath) {
            Write-Warning-Custom "Application Pool '$ApplicationPoolName' already exists"
            Write-Info "Skipping pool creation..."
        } else {
            Write-Info "Creating Application Pool: $ApplicationPoolName"
            New-WebAppPool -Name $ApplicationPoolName -ErrorAction Stop
            
            # Configure the pool
            Set-ItemProperty -Path $poolPath -Name "processModel.identityType" -Value 4 # ApplicationPoolIdentity
            Set-ItemProperty -Path $poolPath -Name "processModel.loadUserProfile" -Value $true
            Set-ItemProperty -Path $poolPath -Name "recycling.periodicRestart.time" -Value 1440 # Daily
            
            Write-Success "Application Pool created and configured"
        }
    }
    catch {
        Write-Error-Custom "Error creating Application Pool: $_"
        exit 1
    }

    # Step 4: Verify application directory exists
    Write-Info "`nStep 4: Verifying Application Directory..."
    if (Test-Path $ApplicationPath) {
        Write-Success "Application directory exists: $ApplicationPath"
    } else {
        Write-Error-Custom "Application directory not found: $ApplicationPath"
        Write-Info "Please copy the published files to: $ApplicationPath"
        exit 1
    }

    # Step 5: Create logs directory
    Write-Info "`nStep 5: Setting up Logging..."
    try {
        $logsPath = Join-Path $ApplicationPath "logs"
        if (-not (Test-Path $logsPath)) {
            New-Item -ItemType Directory -Path $logsPath -Force | Out-Null
            Write-Success "Logs directory created"
        } else {
            Write-Success "Logs directory already exists"
        }
    }
    catch {
        Write-Warning-Custom "Error creating logs directory: $_"
    }

    # Step 6: Set file permissions
    Write-Info "`nStep 6: Setting File Permissions..."
    try {
        Write-Info "Granting permissions to Application Pool..."
        & icacls $ApplicationPath /grant "IIS AppPool\$ApplicationPoolName`:(OI)(CI)F" /T /C 2>&1 | Out-Null
        
        Write-Info "Granting read permissions to IUSR..."
        & icacls $ApplicationPath /grant "IUSR`:(OI)(CI)R" /T /C 2>&1 | Out-Null
        
        Write-Success "Permissions set successfully"
    }
    catch {
        Write-Warning-Custom "Error setting permissions: $_"
    }

    # Step 7: Create or configure IIS website
    Write-Info "`nStep 7: Configuring IIS Website..."
    try {
        $sitePath = "IIS:\Sites\$SiteName"
        
        if (Test-Path $sitePath) {
            Write-Warning-Custom "Website '$SiteName' already exists"
            Write-Info "Updating website configuration..."
            
            Set-ItemProperty -Path $sitePath -Name "applicationPool" -Value $ApplicationPoolName -ErrorAction Stop
            Write-Success "Website updated"
        } else {
            Write-Info "Creating Website: $SiteName"
            New-Website -Name $SiteName `
                       -PhysicalPath $ApplicationPath `
                       -ApplicationPool $ApplicationPoolName `
                       -Port $Port `
                       -HostHeader $Hostname `
                       -ErrorAction Stop | Out-Null
            
            Write-Success "Website created successfully"
        }
    }
    catch {
        Write-Error-Custom "Error configuring website: $_"
        exit 1
    }

    # Step 8: Start application pool and website
    Write-Info "`nStep 8: Starting Application Pool and Website..."
    try {
        $pool = Get-WebAppPoolState -Name $ApplicationPoolName
        if ($pool.Value -ne "Started") {
            Start-WebAppPool -Name $ApplicationPoolName -ErrorAction Stop
            Start-Sleep -Seconds 2
            Write-Success "Application Pool started"
        } else {
            Write-Success "Application Pool already running"
        }

        $site = Get-WebsiteState -Name $SiteName
        if ($site.Value -ne "Started") {
            Start-Website -Name $SiteName -ErrorAction Stop
            Write-Success "Website started"
        } else {
            Write-Success "Website already running"
        }
    }
    catch {
        Write-Error-Custom "Error starting application: $_"
        exit 1
    }

    # Step 9: Verify deployment
    Write-Info "`nStep 9: Verifying Deployment..."
    try {
        Start-Sleep -Seconds 3
        
        $response = $null
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:$Port" -ErrorAction SilentlyContinue
        }
        catch {}
        
        if ($response) {
            Write-Success "Application is responding to requests"
        } else {
            Write-Warning-Custom "Could not reach application at http://localhost:$Port"
            Write-Info "Please verify manually by opening a browser"
        }
    }
    catch {
        Write-Warning-Custom "Error verifying deployment: $_"
    }

    # Summary
    Write-Host "
??????????????????????????????????????????????????????????????????
?  Deployment Complete!                                         ?
??????????????????????????????????????????????????????????????????
" -ForegroundColor Green

    Write-Info "
Application Details:
  � Site Name: $SiteName
  � URL: http://$($Hostname):$Port/
  � Physical Path: $ApplicationPath
  � Application Pool: $ApplicationPoolName
  � Framework: .NET 8.0 ASP.NET Core

Next Steps:
  1. Update appsettings.Production.json with correct database connection string
  2. Verify database connectivity
  3. Configure SSL/HTTPS (if required)
  4. Set up backup jobs
  5. Configure monitoring/logging

Logs Location:
  � Application Logs: $ApplicationPath\logs\
  � IIS Logs: C:\inetpub\logs\LogFiles\

For troubleshooting, check the deployment README file.
"
}

# Execute deployment
try {
    Deploy-Application
}
catch {
    Write-Error-Custom "Deployment failed: $_"
    exit 1
}
