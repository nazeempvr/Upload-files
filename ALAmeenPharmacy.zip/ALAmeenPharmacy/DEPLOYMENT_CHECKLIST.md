# AL AMEEN PHARMACY - DEPLOYMENT CHECKLIST

## ?? PACKAGE INFORMATION
- **Application:** AL Ameen Pharmacy Management System
- **Framework:** .NET 8.0 ASP.NET Core
- **Architecture:** x64 (win-x64)
- **Database:** SQL Server 2016 or Higher
- **IIS Version:** IIS 7.5 or Higher

---

## ??? PRE-DEPLOYMENT (Source Machine)

- [x] Application built in Release mode
- [x] All NuGet packages restored
- [x] Application published successfully
- [x] web.config included in package
- [x] Configuration files included
- [x] Static assets (wwwroot) included
- [x] Deployment guide created
- [x] PowerShell deployment script included

---

## ?? SERVER PREREQUISITES (Target Machine)

Before deploying, ensure on the target Windows Server:

### Required Software
- [ ] Windows Server 2012 R2 or newer
- [ ] .NET 8.0 Hosting Bundle installed
  - Download: https://dotnet.microsoft.com/download/dotnet/8.0
  - Run installer: `dotnet-hosting-8.0.x-win.exe`
  - Restart IIS after: `iisreset /restart`
- [ ] IIS enabled with these features:
  - [ ] Web Server (IIS)
  - [ ] Static Content
  - [ ] ASP.NET Core Module
  - [ ] HTTP Compression
  - [ ] URL Rewrite (optional)

### Verify Installation
```powershell
dotnet --info
```

### Database Requirements
- [ ] SQL Server 2016 or newer
- [ ] Database created: `ShopDb`
- [ ] Database is accessible from web server
- [ ] Appropriate SQL Server login credentials available

---

## ?? DEPLOYMENT STEPS (On Target Server)

### Step 1: Copy Application Files
- [ ] Copy entire folder to target location
  ```
  C:\inetpub\wwwroot\ALAmeenPharmacy\
  ```

### Step 2: Update Configuration
- [ ] Open `appsettings.Production.json`
- [ ] Update connection string:
  ```json
  "DefaultConnection": "Server=YOUR_SERVER;Database=ShopDb;Integrated Security=true"
  ```
- [ ] Update AllowedHosts with your domain
- [ ] Save the file

### Step 3: Set File Permissions (Run as Administrator)
```powershell
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy" /grant "IIS AppPool\ALAmeenPharmacy:(OI)(CI)F" /T /C
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy" /grant "IUSR:(OI)(CI)R" /T /C
```
- [ ] Permissions set successfully

### Step 4: Option A - Use PowerShell Script (RECOMMENDED)
```powershell
# Run as Administrator
.\Deploy-to-IIS.ps1 -ApplicationPath "C:\inetpub\wwwroot\ALAmeenPharmacy" `
                     -ApplicationPoolName "ALAmeenPharmacy" `
                     -SiteName "AL Ameen Pharmacy" `
                     -Port 80 `
                     -Hostname "yourdomain.com"
```
- [ ] Script executed successfully
- [ ] Check output for any warnings or errors

### Step 4: Option B - Manual IIS Configuration

#### Create Application Pool
- [ ] Open IIS Manager (`inetmgr`)
- [ ] Create new Application Pool
  - [ ] Name: `ALAmeenPharmacy`
  - [ ] .NET CLR Version: `No Managed Code`
  - [ ] Pipeline Mode: `Integrated`
  - [ ] Advanced Settings:
    - [ ] Identity: ApplicationPoolIdentity
    - [ ] Load User Profile: True
    - [ ] Recycling > Regular Time Interval: 1440 minutes

#### Create Website/Application
- [ ] In IIS, create new website:
  - [ ] Site Name: `AL Ameen Pharmacy`
  - [ ] Application Pool: `ALAmeenPharmacy`
  - [ ] Physical Path: `C:\inetpub\wwwroot\ALAmeenPharmacy`
  - [ ] Binding: Port 80 (or 443 for HTTPS)
  - [ ] Host Header: (your domain or localhost)

#### Create Logs Directory
```powershell
mkdir "C:\inetpub\wwwroot\ALAmeenPharmacy\logs" -Force
icacls "C:\inetpub\wwwroot\ALAmeenPharmacy\logs" /grant "IIS AppPool\ALAmeenPharmacy:(OI)(CI)F" /T /C
```
- [ ] Logs directory created
- [ ] Permissions set

#### Start IIS Application
- [ ] Select website in IIS Manager
- [ ] Click "Start" in right panel
- [ ] Status should show "Started"

---

## ? POST-DEPLOYMENT VERIFICATION

### Basic Functionality
- [ ] Application loads in browser
  - URL: http://yourdomain.com/ or http://localhost/
- [ ] Login page displays
- [ ] No errors in browser console (F12)

### Database Connection
- [ ] Login works with valid credentials
- [ ] Can navigate to main pages
- [ ] Data loads from database
- [ ] No "Cannot connect to database" errors

### Features Verification
- [ ] Navigation menu works
- [ ] Static files load (CSS, JavaScript)
- [ ] Images display correctly
- [ ] All pages accessible

### Logging & Monitoring
- [ ] Check logs directory exists
- [ ] Application logs being created
- [ ] No permission errors in logs
- [ ] IIS logs being created
  - Location: `C:\inetpub\logs\LogFiles\W3SVC1\`

---

## ?? OPTIONAL: HTTPS/SSL CONFIGURATION

After initial deployment, configure HTTPS:

### Install SSL Certificate
- [ ] Obtain SSL certificate (.pfx file)
- [ ] Run as Administrator:
  ```powershell
  Import-PfxCertificate -FilePath "C:\certificate.pfx" `
    -CertStoreLocation Cert:\LocalMachine\My `
    -Password (ConvertTo-SecureString "password" -AsPlainText -Force)
  ```

### Configure IIS Binding
- [ ] In IIS Manager, edit website bindings
- [ ] Add HTTPS binding:
  - [ ] Type: https
  - [ ] Port: 443
  - [ ] Select installed certificate

### Enable HTTPS Redirect
- [ ] Edit `web.config` in application folder
- [ ] Find "Force HTTPS" rule
- [ ] Change `enabled="false"` to `enabled="true"`
- [ ] Save file

---

## ?? PERFORMANCE & MONITORING

### Monitor Application
```powershell
# Watch logs in real-time
Get-Content -Path "C:\inetpub\wwwroot\ALAmeenPharmacy\logs\stdout*" -Wait

# Check application pool status
Get-WebAppPoolState -Name "ALAmeenPharmacy"

# Check website status
Get-WebsiteState -Name "AL Ameen Pharmacy"
```

### Set Up Backups
- [ ] Configure daily application file backup
- [ ] Configure daily database backup
- [ ] Test restore procedure

### Configure Monitoring
- [ ] Set up application event notifications
- [ ] Monitor disk space usage
- [ ] Monitor IIS logs for errors
- [ ] Set up performance alerts

---

## ?? TROUBLESHOOTING

### If Application Won't Start

1. **Check .NET Hosting Bundle Installation:**
   ```powershell
   dotnet --info
   ```

2. **Check IIS Logs:**
   ```
   C:\inetpub\wwwroot\ALAmeenPharmacy\logs\stdout*
   ```

3. **Restart IIS:**
   ```powershell
   iisreset /restart
   ```

4. **Verify Permissions:**
   ```powershell
   icacls "C:\inetpub\wwwroot\ALAmeenPharmacy" /T
   ```

5. **Check Application Pool State:**
   - IIS Manager ? Application Pools ? ALAmeenPharmacy
   - Status should be "Started"

6. **Check Database Connection:**
   - Verify connection string in `appsettings.Production.json`
   - Test connection from server to SQL Server

### If Database Connection Fails

1. Verify SQL Server service is running
2. Check connection string syntax
3. Verify database exists
4. Test connectivity: `telnet SERVERNAME 1433`

### If Static Files Don't Load

1. Verify `wwwroot` folder exists
2. Check IIS Static Content feature enabled
3. Clear browser cache
4. Check file permissions

---

## ?? CONFIGURATION FILES TO REVIEW

### appsettings.Production.json
Must be updated with production values:
- [ ] Connection string
- [ ] AllowedHosts
- [ ] Logging levels
- [ ] Any other environment-specific settings

### web.config
Pre-configured but review:
- [ ] Verify ASP.NET Core Module v2 is configured
- [ ] Check security headers are appropriate
- [ ] Review HTTPS redirect settings

---

## ?? MAINTENANCE TASKS

### Daily
- [ ] Monitor application logs for errors
- [ ] Check disk space availability
- [ ] Monitor application performance

### Weekly
- [ ] Review IIS logs for patterns
- [ ] Test backup restoration
- [ ] Check for security updates

### Monthly
- [ ] Clean up old logs
- [ ] Review application performance metrics
- [ ] Update security patches

### Quarterly
- [ ] Test complete disaster recovery
- [ ] Review and optimize database
- [ ] Security audit

---

## ?? SUPPORT INFORMATION

### Key Locations
- Application: `C:\inetpub\wwwroot\ALAmeenPharmacy\`
- Config: `C:\inetpub\wwwroot\ALAmeenPharmacy\appsettings.Production.json`
- Logs: `C:\inetpub\wwwroot\ALAmeenPharmacy\logs\`
- IIS Logs: `C:\inetpub\logs\LogFiles\`

### Useful Commands
```powershell
# Restart application
iisreset /restart

# Restart specific pool
Stop-WebAppPool -Name "ALAmeenPharmacy"
Start-WebAppPool -Name "ALAmeenPharmacy"

# Check event logs
Get-EventLog -LogName Application -Newest 20

# Get detailed IIS info
Get-WebSite | Format-List *
Get-WebAppPool | Format-List *
```

---

## ? FINAL SIGN-OFF

- [ ] All deployment steps completed
- [ ] Application tested and working
- [ ] Configuration verified
- [ ] Backups configured
- [ ] Monitoring set up
- [ ] Documentation updated
- [ ] Team informed of deployment

**Deployed By:** ________________  
**Date:** ________________  
**Server:** ________________  
**Notes:** ________________________________________________________________________

---

**For questions or issues, refer to DEPLOYMENT_README.md for detailed information.**
